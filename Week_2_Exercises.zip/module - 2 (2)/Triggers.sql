CREATE OR REPLACE TRIGGER LogTransaction
AFTER INSERT ON Transactions
FOR EACH ROW
BEGIN
    INSERT INTO AuditLog (AuditID, TransactionID, Action, ActionDate, Details)
    VALUES (AuditLog_SEQ.NEXTVAL, :NEW.TransactionID, 'INSERT', SYSDATE, 'Transaction inserted for account ID ' || :NEW.AccountID);
END LogTransaction;
/
CREATE OR REPLACE TRIGGER UpdateCustomerLastModified
BEFORE UPDATE ON Customers
FOR EACH ROW
BEGIN
    :NEW.LastModified := SYSDATE;
END UpdateCustomerLastModified;
/
CREATE OR REPLACE TRIGGER LogTransaction
AFTER INSERT ON Transactions
FOR EACH ROW
BEGIN
    INSERT INTO AuditLog (AuditID, TransactionID, Action, ActionDate, Details)
    VALUES (AuditLog_SEQ.NEXTVAL, :NEW.TransactionID, 'INSERT', SYSDATE, 'Transaction inserted for account ID ' || :NEW.AccountID);
END LogTransaction;
/
CREATE OR REPLACE TRIGGER CheckTransactionRules
BEFORE INSERT ON Transactions
FOR EACH ROW
DECLARE
    v_balance NUMBER;
BEGIN
    -- Check for withdrawals exceeding balance
    IF :NEW.TransactionType = 'WITHDRAWAL' THEN
        SELECT Balance INTO v_balance
        FROM Accounts
        WHERE AccountID = :NEW.AccountID;

        IF v_balance < :NEW.Amount THEN
            RAISE_APPLICATION_ERROR(-20002, 'Insufficient funds for withdrawal.');
        END IF;

    -- Check for deposits with non-positive amounts
    ELSIF :NEW.TransactionType = 'DEPOSIT' THEN
        IF :NEW.Amount <= 0 THEN
            RAISE_APPLICATION_ERROR(-20003, 'Deposit amount must be positive.');
        END IF;
    END IF;
END CheckTransactionRules;
/
