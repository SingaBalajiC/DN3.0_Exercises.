CREATE OR REPLACE PROCEDURE SafeTransferFunds (
    p_from_account_id IN NUMBER,
    p_to_account_id IN NUMBER,
    p_amount IN NUMBER
) IS
    v_from_balance NUMBER;
    v_to_balance NUMBER;
BEGIN
    -- Start a transaction
    BEGIN
        -- Check balances
        SELECT Balance INTO v_from_balance FROM Accounts WHERE AccountID = p_from_account_id;
        SELECT Balance INTO v_to_balance FROM Accounts WHERE AccountID = p_to_account_id;

        IF v_from_balance < p_amount THEN
            RAISE_APPLICATION_ERROR(-20001, 'Insufficient funds in the source account.');
        END IF;

        -- Transfer funds
        UPDATE Accounts SET Balance = Balance - p_amount WHERE AccountID = p_from_account_id;
        UPDATE Accounts SET Balance = Balance + p_amount WHERE AccountID = p_to_account_id;

        -- Insert transaction record
        INSERT INTO Transactions (TransactionID, AccountID, TransactionDate, Amount, TransactionType)
        VALUES (Transactions_SEQ.NEXTVAL, p_from_account_id, SYSDATE, p_amount, 'Debit');

        INSERT INTO Transactions (TransactionID, AccountID, TransactionDate, Amount, TransactionType)
        VALUES (Transactions_SEQ.NEXTVAL, p_to_account_id, SYSDATE, p_amount, 'Credit');

        -- Commit transaction
        COMMIT;

    EXCEPTION
        WHEN OTHERS THEN
            -- Rollback transaction on error
            ROLLBACK;
            -- Log error
            DBMS_OUTPUT.PUT_LINE('Error during fund transfer: ' || SQLERRM);
    END;
END SafeTransferFunds;
/
CREATE OR REPLACE PROCEDURE SafeTransferFunds (
    p_from_account_id IN NUMBER,
    p_to_account_id IN NUMBER,
    p_amount IN NUMBER
) IS
    v_from_balance NUMBER;
    v_to_balance NUMBER;
BEGIN
    -- Start a transaction
    BEGIN
        -- Check balances
        SELECT Balance INTO v_from_balance FROM Accounts WHERE AccountID = p_from_account_id;
        SELECT Balance INTO v_to_balance FROM Accounts WHERE AccountID = p_to_account_id;

        IF v_from_balance < p_amount THEN
            RAISE_APPLICATION_ERROR(-20001, 'Insufficient funds in the source account.');
        END IF;

        -- Transfer funds
        UPDATE Accounts SET Balance = Balance - p_amount WHERE AccountID = p_from_account_id;
        UPDATE Accounts SET Balance = Balance + p_amount WHERE AccountID = p_to_account_id;

        -- Insert transaction record
        INSERT INTO Transactions (TransactionID, AccountID, TransactionDate, Amount, TransactionType)
        VALUES (Transactions_SEQ.NEXTVAL, p_from_account_id, SYSDATE, p_amount, 'Debit');

        INSERT INTO Transactions (TransactionID, AccountID, TransactionDate, Amount, TransactionType)
        VALUES (Transactions_SEQ.NEXTVAL, p_to_account_id, SYSDATE, p_amount, 'Credit');

        -- Commit transaction
        COMMIT;

    EXCEPTION
        WHEN OTHERS THEN
            -- Rollback transaction on error
            ROLLBACK;
            -- Log error
            DBMS_OUTPUT.PUT_LINE('Error during fund transfer: ' || SQLERRM);
    END;
END SafeTransferFunds;
/
CREATE OR REPLACE PROCEDURE UpdateSalary (
    p_employee_id IN NUMBER,
    p_percentage IN NUMBER
) IS
BEGIN
    -- Update employee salary
    UPDATE Employees
    SET Salary = Salary * (1 + p_percentage / 100)
    WHERE EmployeeID = p_employee_id;

    IF SQL%ROWCOUNT = 0 THEN
        RAISE_APPLICATION_ERROR(-20002, 'Employee ID does not exist.');
    END IF;

    -- Commit transaction
    COMMIT;

EXCEPTION
    WHEN OTHERS THEN
        -- Rollback transaction on error
        ROLLBACK;
        -- Log error
        DBMS_OUTPUT.PUT_LINE('Error updating salary: ' || SQLERRM);
END UpdateSalary;
/
CREATE OR REPLACE PROCEDURE AddNewCustomer (
    p_customer_id IN NUMBER,
    p_name IN VARCHAR2,
    p_dob IN DATE,
    p_balance IN NUMBER
) IS
BEGIN
    -- Attempt to insert new customer
    BEGIN
        INSERT INTO Customers (CustomerID, Name, DOB, Balance, LastModified)
        VALUES (p_customer_id, p_name, p_dob, p_balance, SYSDATE);

        -- Commit transaction
        COMMIT;

    EXCEPTION
        WHEN DUP_VAL_ON_INDEX THEN
            -- Handle duplicate customer ID error
            DBMS_OUTPUT.PUT_LINE('Customer ID already exists.');
            ROLLBACK;
        WHEN OTHERS THEN
            -- Handle other errors
            DBMS_OUTPUT.PUT_LINE('Error adding customer: ' || SQLERRM);
            ROLLBACK;
    END;
END AddNewCustomer;
/
