commit
/
DECLARE
    CURSOR c_customers IS
        SELECT CustomerID, DOB
        FROM Customers;

    v_current_date DATE := SYSDATE;
BEGIN
    FOR r_customer IN c_customers LOOP
        -- Calculate age
        IF MONTHS_BETWEEN(v_current_date, r_customer.DOB) / 12 > 60 THEN
            -- Apply discount for loans
            UPDATE Loans
            SET InterestRate = InterestRate * 0.99
            WHERE CustomerID = r_customer.CustomerID;
        END IF;
    END LOOP;

    COMMIT;
END;
/
DECLARE
    CURSOR c_customers IS
        SELECT CustomerID, Balance
        FROM Customers;
BEGIN
    FOR r_customer IN c_customers LOOP
        IF r_customer.Balance > 10000 THEN
            UPDATE Customers
            SET IsVIP = 'Y'
            WHERE CustomerID = r_customer.CustomerID;
        END IF;
    END LOOP;

    COMMIT;
END;
/
DECLARE
    CURSOR c_loans_due IS
        SELECT l.CustomerID, c.Name, l.DueDate
        FROM Loans l
        JOIN Customers c ON l.CustomerID = c.CustomerID
        WHERE l.DueDate BETWEEN SYSDATE AND SYSDATE + 30;
BEGIN
    FOR r_loan IN c_loans_due LOOP
        DBMS_OUTPUT.PUT_LINE('Reminder: Loan for customer ' || r_loan.Name ||
                             ' (ID: ' || r_loan.CustomerID || ') is due on ' ||
                             TO_CHAR(r_loan.DueDate, 'MM/DD/YYYY'));
    END LOOP;
END;
/
