DECLARE
    CURSOR c_loans IS
        SELECT LoanID, InterestRate
        FROM Loans;

    v_loan_id Loans.LoanID%TYPE;
    v_old_interest_rate Loans.InterestRate%TYPE;
    v_new_interest_rate NUMBER := 5; -- New interest rate policy

BEGIN
    OPEN c_loans;
    LOOP
        FETCH c_loans INTO v_loan_id, v_old_interest_rate;
        EXIT WHEN c_loans%NOTFOUND;

        -- Update the interest rate for the loan
        UPDATE Loans
        SET InterestRate = v_new_interest_rate
        WHERE LoanID = v_loan_id;

    END LOOP;
    CLOSE c_loans;

    -- Commit the transaction
    COMMIT;

    DBMS_OUTPUT.PUT_LINE('Interest rates updated based on new policy.');
END;
/
DECLARE
    CURSOR c_transactions IS
        SELECT c.CustomerID, c.Name, t.TransactionID, t.TransactionDate, t.Amount, t.TransactionType
        FROM Customers c
        JOIN Transactions t ON c.CustomerID = t.AccountID
        WHERE EXTRACT(MONTH FROM t.TransactionDate) = EXTRACT(MONTH FROM SYSDATE)
        AND EXTRACT(YEAR FROM t.TransactionDate) = EXTRACT(YEAR FROM SYSDATE);

    v_customer_id Customers.CustomerID%TYPE;
    v_customer_name Customers.Name%TYPE;
    v_transaction_id Transactions.TransactionID%TYPE;
    v_transaction_date Transactions.TransactionDate%TYPE;
    v_amount Transactions.Amount%TYPE;
    v_transaction_type Transactions.TransactionType%TYPE;

BEGIN
    OPEN c_transactions;
    LOOP
        FETCH c_transactions INTO v_customer_id, v_customer_name, v_transaction_id, v_transaction_date, v_amount, v_transaction_type;
        EXIT WHEN c_transactions%NOTFOUND;

        DBMS_OUTPUT.PUT_LINE('Statement for Customer ID: ' || v_customer_id);
        DBMS_OUTPUT.PUT_LINE('Name: ' || v_customer_name);
        DBMS_OUTPUT.PUT_LINE('Transaction ID: ' || v_transaction_id);
        DBMS_OUTPUT.PUT_LINE('Date: ' || v_transaction_date);
        DBMS_OUTPUT.PUT_LINE('Amount: ' || v_amount);
        DBMS_OUTPUT.PUT_LINE('Type: ' || v_transaction_type);
        DBMS_OUTPUT.PUT_LINE('------------------------------');

    END LOOP;
    CLOSE c_transactions;
END;
/
DECLARE
    CURSOR c_accounts IS
        SELECT AccountID, Balance
        FROM Accounts;

    v_account_id Accounts.AccountID%TYPE;
    v_balance Accounts.Balance%TYPE;
    v_fee NUMBER := 50; -- Annual maintenance fee

BEGIN
    OPEN c_accounts;
    LOOP
        FETCH c_accounts INTO v_account_id, v_balance;
        EXIT WHEN c_accounts%NOTFOUND;

        -- Deduct the annual fee from the account balance
        UPDATE Accounts
        SET Balance = Balance - v_fee
        WHERE AccountID = v_account_id;

    END LOOP;
    CLOSE c_accounts;

    -- Commit the transaction
    COMMIT;

    DBMS_OUTPUT.PUT_LINE('Annual fees applied to all accounts.');
END;
/
DECLARE
    CURSOR c_loans IS
        SELECT LoanID, InterestRate
        FROM Loans;

    v_loan_id Loans.LoanID%TYPE;
    v_old_interest_rate Loans.InterestRate%TYPE;
    v_new_interest_rate NUMBER := 5; -- New interest rate policy

BEGIN
    OPEN c_loans;
    LOOP
        FETCH c_loans INTO v_loan_id, v_old_interest_rate;
        EXIT WHEN c_loans%NOTFOUND;

        -- Update the interest rate for the loan
        UPDATE Loans
        SET InterestRate = v_new_interest_rate
        WHERE LoanID = v_loan_id;

    END LOOP;
    CLOSE c_loans;

    -- Commit the transaction
    COMMIT;

    DBMS_OUTPUT.PUT_LINE('Interest rates updated based on new policy.');
END;
/
